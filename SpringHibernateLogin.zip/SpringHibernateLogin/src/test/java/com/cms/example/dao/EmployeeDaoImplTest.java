package com.cms.example.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cms.example.model.Employee;

public class EmployeeDaoImplTest {
	private EmployeeDao employeeDao;

	@Before
	public void setUp() throws Exception {
		employeeDao = new EmployeeDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		employeeDao = null;
	}

	@Test
	public void addEmployeeTest() throws Exception{
		Employee employee = employeeDao.getEmployeeeById(104);
		
		if(employee==null) {
	      Employee emp1 = new Employee();
	      emp1.setEmpId(104);
	      emp1.setEmpName("test");
	      emp1.setAge(25);
	      emp1.setSalary(20000.0);
	      emp1.setEmpAddress("testbang");
	       
	      employeeDao.addEmployee(emp1);
	     Employee employee1 = employeeDao.getEmployeeeById(104);
	     assertEquals(104, employee1.getEmpId());
	     assertEquals("test", employee1.getEmpName());
	     assertEquals("testbang", employee1.getEmpAddress());
		}
		
	}
	
	@Test
	public void listEmployeeTest() {
		List<Employee> list = employeeDao.listEmployee();
		assertTrue(list.size()>0);
	}
	
	@Test
	public void deleteEmployeeTest() {
		Employee employee1 = employeeDao.getEmployeeeById(101);
		employeeDao.deleteEmployee(employee1);
		assertEquals(101, employee1.getEmpId());
	}
	
	@Test
	public void getEmployeeeByIdTest() {
		Employee emp = employeeDao.getEmployeeeById(101);
		assertEquals(101, emp.getEmpId());
	}
}
